import module as mm
print(mm.sub(4,7))
