from module import sub
print(sub(2,4))
