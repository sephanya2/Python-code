# File Reading and Word Count

try:
    filename = input("Enter file name: ")
    
    with open(filename, 'r') as file:
        content = file.read()
        print("\nFile Contents:\n")
        print(content)
        
        words = content.split()
        print("\nTotal number of words:", len(words))

except FileNotFoundError:
    print("Error: File not found!")

except Exception as e:
    print("An error occurred:", e)
